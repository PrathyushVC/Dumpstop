from monai.transforms import (
    Compose, LoadImageD, AddChanneld, ScaleIntensityd,
    RandRotate90d, RandSpatialCropd, ToTensord
)

class SegmentationTransforms:
    """
    Defines training and validation transforms.
    """
    def __init__(self, cfg):
        self.train_transform = Compose([
            LoadImageD(keys=["image", "label"], image_only=False, memmap=True),
            AddChanneld(keys=["image", "label"]),
            ScaleIntensityd(keys=["image"]),
            RandRotate90d(keys=["image", "label"], prob=0.5),
            RandSpatialCropd(
                keys=["image", "label"],
                roi_size=[-1, -1, cfg['transforms']['z_crop_size']],
                random_size=False
            ),
            ToTensord(keys=["image", "label"]),
        ])
        self.val_transform = Compose([
            LoadImageD(keys=["image", "label"], image_only=False, memmap=True),
            AddChanneld(keys=["image", "label"]),
            ScaleIntensityd(keys=["image"]),
            ToTensord(keys=["image", "label"]),
        ])

    def get_train(self):
        return self.train_transform

    def get_val(self):
        return self.val_transform
