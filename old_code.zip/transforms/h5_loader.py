import h5py
import numpy as np
from monai.transforms import Transform

class H5Loader(Transform):
    """
    Lazy-load a 3D volume and its label from an HDF5 file.
    """
    def __init__(self, h5_path, slice_roi=None):
        self.h5_path = h5_path
        self.slice_roi = slice_roi

    def __call__(self, data):
        key = data["key"]
        with h5py.File(self.h5_path, "r") as f:
            grp = f[key]
            img = grp["image"]
            lbl = grp["label"]
            if self.slice_roi:
                z0, z1 = self.slice_roi
                img = img[:, :, z0:z1]
                lbl = lbl[:, :, z0:z1]
            return {
                "image": img.astype(np.float32),
                "label": lbl.astype(np.uint8)
            }
