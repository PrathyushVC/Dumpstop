import torch
import torch.nn.functional as F
from monai.losses import DiceLoss

class SurfaceVolumeLoss(torch.nn.Module):
    """
    Combines Dice loss with a penalty on surface-to-volume ratio
    to discourage fragmented predictions.
    """
    def __init__(self, dice_weight=1.0, surface_weight=0.1):
        super().__init__()
        self.dice = DiceLoss(sigmoid=True)
        self.surface_weight = surface_weight

    def forward(self, pred, target):
        dice_loss = self.dice(pred, target)
        pred_bin = (pred > 0.5).float()
        kernel = torch.ones((1,1,3,3,3), device=pred.device)
        neighbor_count = F.conv3d(pred_bin, kernel, padding=1)
        boundary = (pred_bin * (neighbor_count < 27).float()).abs()
        surface = boundary.sum()
        volume = pred_bin.sum() + 1e-6
        ratio = surface / volume
        return dice_loss + self.surface_weight * ratio
