import os
import h5py
import nibabel as nib
from glob import glob

def convert_niis_to_hdf5(nii_dir, out_h5_path):
    """
    Read every .nii.gz in nii_dir, store image+label in one HDF5 file
    for lazy access.
    """
    paths = sorted(glob(os.path.join(nii_dir, "*.nii.gz")))
    with h5py.File(out_h5_path, "w") as h5f:
        for p in paths:
            name = os.path.splitext(os.path.basename(p))[0]
            img = nib.load(p).get_fdata(dtype="float32")
            grp = h5f.create_group(name)
            grp.create_dataset("image", data=img, compression="gzip")
            lbl_path = p.replace("images", "labels")
            lbl = nib.load(lbl_path).get_fdata(dtype="uint8")
            grp.create_dataset("label", data=lbl, compression="gzip")

if __name__ == "__main__":
    convert_niis_to_hdf5(
        "/mnt/data/your_dataset/images",
        "/mnt/data/your_dataset/ribs.h5"
    )
