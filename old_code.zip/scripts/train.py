import os
import torch
import mlflow
from monai.inferers import sliding_window_inference
from monai.metrics import DiceMetric
from monai.optimizers import Novograd
from monai.utils import set_determinism

from utils.config import Config
from utils.model_utils import save_model
from utils.data_module_h5 import DataModuleH5
from transforms.transforms import SegmentationTransforms
from models.unet3d import get_model
from losses.surface_volume_loss import SurfaceVolumeLoss

def main():
    # load config
    cfg = Config.load(os.path.join(os.path.dirname(__file__), "../configs/config.json")).config
    set_determinism(seed=cfg["training"]["seed"])

    # data and transforms
    data_module = DataModuleH5(cfg)
    transforms = SegmentationTransforms(cfg)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = get_model(
        cfg["model"]["in_channels"],
        cfg["model"]["out_channels"],
        cfg["model"]["layer_sizes"]
    ).to(device)

    loss_fn = SurfaceVolumeLoss(surface_weight=cfg["mlflow"]["surface_weight"])
    optimizer = Novograd(model.parameters(), lr=cfg["training"]["learning_rate"])

    mlflow.set_tracking_uri(cfg["mlflow"]["tracking_uri"])
    mlflow.set_experiment(cfg["mlflow"]["experiment_name"])

    best_val_loss = float("inf")
    for epoch in range(cfg["training"]["num_epochs"]):
        # training
        model.train()
        train_loss = 0
        for batch in data_module.train_loader():
            img, lbl = batch["image"].to(device), batch["label"].to(device)
            optimizer.zero_grad()
            output = model(img)
            loss = loss_fn(output, lbl)
            loss.backward()
            optimizer.step()
            train_loss += loss.item()
        train_loss /= len(data_module.train_loader())

        # validation
        model.eval()
        val_loss = 0
        with torch.no_grad():
            for batch in data_module.val_loader():
                img, lbl = batch["image"].to(device), batch["label"].to(device)
                output = sliding_window_inference(img, tuple(img.shape[2:]), 1, model)
                val_loss += loss_fn(output, lbl).item()
        val_loss /= len(data_module.val_loader())

        # log
        mlflow.log_metric("train_loss", train_loss, step=epoch)
        mlflow.log_metric("val_loss", val_loss, step=epoch)

        # checkpoint
        if val_loss < best_val_loss:
            best_val_loss = val_loss
            ckpt_path = os.path.join(project_dir, "models", f"best_epoch_{epoch}.pt")
            save_model(model, ckpt_path)
            mlflow.log_artifact(ckpt_path)

if __name__ == "__main__":
    main()
