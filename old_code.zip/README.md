# Rib Segmentation Project

Organized directory structure for a MONAI-based 3D rib segmentation pipeline with MLflow tracking and HDF5 lazy-loading.

```
rib_seg_project_py/
├── configs/
│   └── config.json           # JSON config for model, data, transforms, dataloader, MLflow
├── losses/
│   └── surface_volume_loss.py # Custom loss combining Dice + surface-volume penalty
├── transforms/
│   ├── transforms.py         # MONAI Compose transforms with memmap, rotation, z-crop
│   └── h5_loader.py          # Lazy-load 3D volumes from HDF5 archive
├── utils/
│   ├── config.py             # Config class to save/load JSON config
│   ├── model_utils.py        # save_model/load_model for full-model checkpointing
│   └── data_module_h5.py     # DataModule using HDF5 lazy loading & DataLoader setup
├── models/
│   └── unet3d.py             # get_model() returns a MONAI 3D UNet instance
├── scripts/
│   ├── build_hdf5.py         # Convert .nii.gz to ribs.h5 for lazy random-access
│   └── train.py              # Main training loop with MLflow logging & checkpoints
└── README.md                 # This file

## Setup & Usage

1. **Install dependencies** (example):
   ```bash
   conda create -n monai_env python=3.9
   conda activate monai_env
   pip install monai nibabel h5py mlflow torch torchvision
   ```

2. **Convert dataset**:
   ```bash
   python scripts/build_hdf5.py
   ```

3. **Configure**:
   - Edit `configs/config.json` paths and hyperparameters as needed.

4. **Train**:
   ```bash
   sbatch scripts/train.sbatch
   ```
   or
   ```bash
   python scripts/train.py
   ```

5. **Checkpoints & Logs**:
   - Model checkpoints stored in `models/` as full-model `.pt`.
   - MLflow logs under the URI specified in `configs/config.json`.

## File Adjustments

- Adjust `dataloader` settings (num_workers, pin_memory, etc.) in JSON.
- Add or modify transforms in `transforms/transforms.py`.
- Modify model architecture in `models/unet3d.py`.
