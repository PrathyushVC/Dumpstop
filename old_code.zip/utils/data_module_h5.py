import h5py
from monai.data import Dataset, DataLoader
from monai.transforms import Compose
from transforms.h5_loader import H5Loader

class DataModuleH5:
    """
    DataModule using HDF5 lazy-loading with MONAI.
    """
    def __init__(self, cfg):
        self.cfg = cfg
        self.h5_path = cfg["data"]["h5_path"]
        with h5py.File(self.h5_path, "r") as f:
            keys = list(f.keys())
        n = len(keys)
        t_end = int(n * cfg["training"]["train_split"])
        v_end = t_end + int(n * cfg["training"]["val_split"])
        self.train_keys = keys[:t_end]
        self.val_keys = keys[t_end:v_end]
        self.test_keys = keys[v_end:]
        self.train_tfm = Compose([
            H5Loader(self.h5_path, slice_roi=None),
            # further transforms can be added here...
        ])
        self.val_tfm = Compose([
            H5Loader(self.h5_path, slice_roi=None),
            # validation transforms...
        ])

    def get_dataloader(self, keys, train=True):
        ds = Dataset(
            data=[{"key": k} for k in keys],
            transform=self.train_tfm if train else self.val_tfm
        )
        params = self.cfg["dataloader"]
        return DataLoader(
            ds,
            batch_size=self.cfg["training"]["batch_size"],
            shuffle=train,
            num_workers=params["num_workers"],
            pin_memory=params["pin_memory"],
            persistent_workers=params["persistent_workers"],
            prefetch_factor=params["prefetch_factor"]
        )

    def train_loader(self):
        return self.get_dataloader(self.train_keys, train=True)

    def val_loader(self):
        return self.get_dataloader(self.val_keys, train=False)

    def test_loader(self):
        return self.get_dataloader(self.test_keys, train=False)
