import json
from pathlib import Path

class Config:
    """Handles saving and loading experiment configuration as JSON."""

    def __init__(self, model, training, transforms, mlflow, data, dataloader):
        self.config = {
            "model": model,
            "training": training,
            "transforms": transforms,
            "mlflow": mlflow,
            "data": data,
            "dataloader": dataloader
        }

    def save(self, path):
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, 'w') as f:
            json.dump(self.config, f, indent=2)

    @classmethod
    def load(cls, path):
        with open(path, 'r') as f:
            data = json.load(f)
        return cls(**data)
