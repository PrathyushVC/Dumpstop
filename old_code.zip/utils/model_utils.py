import torch

def save_model(model, path):
    """Save full model for easy loading."""
    torch.save(model, path)

def load_model(path, map_location=None):
    """Load a full model previously saved with save_model."""
    return torch.load(path, map_location=map_location)
