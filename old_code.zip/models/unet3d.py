from monai.networks.nets import UNet

def get_model(in_channels, out_channels, features):
    """
    Build a 3D UNet model with given parameters.
    """
    return UNet(
        dimensions=3,
        in_channels=in_channels,
        out_channels=out_channels,
        channels=features,
        strides=[2] * (len(features)-1),
        num_res_units=2,
    )
