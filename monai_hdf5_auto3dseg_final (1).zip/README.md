# MONAI Auto3DSeg HDF5 Benchmark

## Overview
This project demonstrates how to automatically benchmark multiple 3D medical image segmentation models using MONAI's **Auto3DSeg** CLI (`auto3dseg_train`) directly on an HDF5-formatted dataset. It handles data splitting, data-list creation, model training, validation, inference, and logging with minimal manual coding.

## Directory Structure
```
monai_hdf5_auto3dseg/
├── config/
│   ├── algorithms.yaml       # List of segmentation algorithms to run
│   ├── trainer.yaml          # Training hyperparameters and MLflow settings
│   ├── splits.json           # Generated train/val/test splits
│   └── data_list.json        # Generated data list for Auto3DSeg
├── scripts/
│   ├── generate_splits.py    # Splits HDF5 keys into train/val/test
│   ├── create_data_list.py   # Generates data_list.json referencing HDF5 samples
│   └── run_auto3dseg.sh      # Orchestrates the full Auto3DSeg workflow
├── auto3dseg_output/         # Output directory created by Auto3DSeg
│   ├── logs/                 # MLflow logs and metrics
│   ├── model_dynunet/        # Trained DynUNet bundle
│   ├── model_segresnet/      # Trained SegResNet bundle
│   └── model_swinunetr/      # Trained SwinUNETR bundle
└── README.md                 # This detailed documentation
```

## Prerequisites
- **Python 3.8+**
- **PyTorch** (tested with 1.12+)
- **MONAI** with Auto3DSeg support:  
  ```bash
  pip install monai[all]
  ```
- **MLflow** for experiment tracking:  
  ```bash
  pip install mlflow
  ```
- **h5py** and **scikit-learn** for data handling:
  ```bash
  pip install h5py scikit-learn
  ```

## Dataset Format
Your HDF5 dataset should follow this structure:
```
dataset.h5
├── sample_001/
│   ├── image   (NIfTI volume or numpy array)
│   └── label
├── sample_002/
│   ├── image
│   └── label
...
```
Each `sample_xxx` group must contain `image` and `label` datasets. Images and labels should already be in **channel-first** format (e.g., `[C, H, W, D]`).

## Configuration Files

### `config/algorithms.yaml`
List the algorithms to benchmark:
```yaml
algorithms:
  - dynunet
  - segresnet
  - swinunetr
```

### `config/trainer.yaml`
Define training parameters and MLflow settings:
```yaml
trainer:
  max_epochs: 100
  num_epochs_per_validation: 1
  learning_rate: 1e-4
  batch_size: 2
  amp: true                # Enable automatic mixed precision
  project_name: segmentation_benchmark
  run_name: benchmark_auto3dseg
```

## Workflow Steps

### 1. Generate Splits
Split your HDF5 keys into training, validation, and testing sets.
```bash
python scripts/generate_splits.py path/to/dataset.h5 config/splits.json
```
Default split is 70% train, 20% val, 10% test.

### 2. Create Data List
Create `config/data_list.json` to feed into Auto3DSeg:
```bash
python scripts/create_data_list.py path/to/dataset.h5 config/splits.json config/data_list.json
```

### 3. Run Auto3DSeg Benchmark
Use the bash script to run the full pipeline:
```bash
chmod +x scripts/run_auto3dseg.sh
./scripts/run_auto3dseg.sh path/to/dataset.h5
```
This will:
1. Generate splits and data list
2. Launch `auto3dseg_train` with your configs
3. Train and validate each algorithm
4. Log metrics and save best bundles under `auto3dseg_output/`

## Monitoring and Results
- **MLflow UI**: Launch with:
  ```bash
  mlflow ui --backend-store-uri auto3dseg_output/mlruns
  ```
  Access at `http://localhost:5000`.
- **Model Bundles**: Saved in `auto3dseg_output/model_<algo>/` each containing model weights, config JSONs, and evaluation summaries.

## Advanced Usage
- **Add or Remove Algorithms**: Edit `config/algorithms.yaml`.
- **Adjust Hyperparameters**: Edit `config/trainer.yaml`.
- **Custom CLI Flags**: You can pass additional flags to `auto3dseg_train` in `run_auto3dseg.sh`.
- **Multi-GPU**: Auto3DSeg will detect available GPUs automatically.

## Troubleshooting
- **Missing Dependencies**: Ensure `monai[all]`, `mlflow`, `h5py`, `scikit-learn` are installed.
- **Data List Parsing**: Ensure HDF5 paths in `data_list.json` use the `h5path::/group/dataset` notation.
- **GPU Errors**: Check CUDA availability and NCCL backend configuration.

## License & Contact
This template is MIT-licensed. For questions or contributions, please open an issue or submit a PR in your project repository.
