#!/usr/bin/env bash
# Usage:
#   ./run_auto3dseg.sh dataset.h5
H5_PATH=$1
# Step 1: Generate splits
python scripts/generate_splits.py "$H5_PATH" config/splits.json
# Step 2: Create data_list.json for auto3dseg
python scripts/create_data_list.py "$H5_PATH" config/splits.json config/data_list.json
# Step 3: Run MONAI Auto3DSeg CLI
auto3dseg_train \
  --data_list config/data_list.json \
  --algo_config config/algorithms.yaml \
  --train_conf config/trainer.yaml \
  --output_dir auto3dseg_output
