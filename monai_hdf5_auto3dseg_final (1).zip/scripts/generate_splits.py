import h5py, json, sys
from sklearn.model_selection import train_test_split

def get_all_keys(h5_path):
    with h5py.File(h5_path, 'r') as f:
        return sorted(list(f.keys()))

if __name__ == "__main__":
    h5_path, out_path = sys.argv[1], sys.argv[2]
    keys = get_all_keys(h5_path)
    train, temp = train_test_split(keys, test_size=0.3, random_state=42)
    val, test = train_test_split(temp, test_size=0.33, random_state=42)
    with open(out_path, 'w') as f:
        json.dump({'train': train, 'val': val, 'test': test}, f, indent=2)
