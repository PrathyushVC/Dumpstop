import h5py, json, sys

def main(h5_path, splits_json, data_list_out):
    splits = json.load(open(splits_json))
    data_list = []
    for phase in ['train', 'val', 'test']:
        for key in splits[phase]:
            data_list.append({
                'image': f'{h5_path}::/{key}/image',
                'label': f'{h5_path}::/{key}/label'
            })
    with open(data_list_out, 'w') as f:
        json.dump(data_list, f, indent=2)

if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2], sys.argv[3])
